import type { Metadata } from 'next'

export const metadata: Metadata = {
  title: 'Tutoring Services – Online & Home Tuition | Avenfield Tutors',
  description:
    'Avenfield Tutors offers verified online and home tutoring for O Level, A Level, IELTS, MDCAT, CSS/PMS and 50+ subjects across Pakistan, UAE & UK.',
  keywords: [
    'online tutoring Pakistan', 'home tuition Lahore', 'O Level tutor',
    'A Level tutor', 'IELTS coaching', 'MDCAT preparation', 'CSS PMS coaching',
    'Avenfield Tutors services',
  ],
  openGraph: {
    title: 'Tutoring Services – Online & Home Tuition | Avenfield Tutors',
    description:
      'Expert online and home tutoring for O Level, A Level, IELTS, MDCAT, CSS and 50+ subjects. Verified tutors. Flexible schedules.',
    type: 'website',
    locale: 'en_PK',
    siteName: 'Avenfield Tutors',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Tutoring Services | Avenfield Tutors',
    description: 'Verified online and home tutoring across Pakistan, UAE & UK.',
  },
  alternates: {
    canonical: 'https://avenfield-tutors.vercel.app/services',
  },
}

export default function ServicesLayout({ children }: { children: React.ReactNode }) {
  return children
}